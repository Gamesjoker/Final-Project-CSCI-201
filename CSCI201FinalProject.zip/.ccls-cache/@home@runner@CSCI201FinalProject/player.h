#ifndef Boss
#define Player
#include <iostream>
#include <random>
#include <string>
#include <stdlib.h>
#include <time.h>

#endif