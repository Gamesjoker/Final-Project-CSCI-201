#ifndef Boss
#define Boss
#include <iostream>
#include <random>
using namespace std;
class boss
{
private:
  int HP=100;
  int phys_damage = 5;
  string Spell_name[5]={"Fire ball","Lightning strike","Frozen ground","Sun beam","Earth splitter"};
  int Spell_damage[5]={10,8,5,7,9};
  int Spell_cooldown[5]={0,0,0,0,0};
public:
  
};

#endif