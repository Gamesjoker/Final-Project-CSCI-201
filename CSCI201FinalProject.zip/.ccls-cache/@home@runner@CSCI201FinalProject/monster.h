#include <iostream>
#include <random>
#include <string>
#include <stdlib.h>
#include <time.h>

using namespace std;

class Monster
{
public:
  Monster(int monHP, int monDamage) {
    srand(time(NULL));
    monHP = rand() % 20;
    monDamage = rand() % 10;

    monsterHP = monHP + 1;
    monsterDamage = monDamage + 1;
  }
  int getMonsterHP() {
    return monsterHP;
  }
  int getMonsterDamage() {
    return monsterDamage;
  }
private:
  int monsterHP;
  int monsterDamage;
};