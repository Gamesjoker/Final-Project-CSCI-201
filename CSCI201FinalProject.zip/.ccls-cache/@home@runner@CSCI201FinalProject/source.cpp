#include "Boss.h"
#include "Monster.h"
#include "Player.h"
#include <iostream>
#include <limits>
#include <random>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <vector>
using namespace std;

void checkint(int& i, int lower_end, int upper_end) {
  while (true) {
    try {
      cout <<"Your choice is:";
      cin >> i;
      if (cin.fail()) {
        throw "Invalid";
      } else if (i >= lower_end && i <= upper_end) {
        break;
      } else {
        throw(i);
      }
    } catch (const char *msg) {
      cin.clear();
      cin.ignore(10, '\n');
      cout << "Error: Not a valid input." << endl;
    } catch (int i) {
      cin.clear();
      cin.ignore(10, '\n');
      cout << "Error: input out of range. Try again!" << endl;
    }
  }
}

int main() {
  string playerName;
  int i, a, d, h, turn;
  int bossHP, playerHP, playerDamage;
  int monsterHP, monsterDamage;
  int HPItemCount, dmgItemCount;

  vector<string> Weapons(1);
  vector<string> Items(8);

  Weapons[0] = "Short Sword";
  Items[0] = "Helmet";
  Items[1] = "Armor";
  Items[2] = "Gloves";
  Items[3] = "Boots";
  Items[4] = "Trousers";
  Items[5] = "Ring #1";
  Items[6] = "Ring #2";
  Items[7] = "Amulet";

  cout << "Enter your name" << endl;
  getline(cin >> ws, playerName);
  player Player1(playerName);
  boss Boss1(0, 0);
  cout << Boss1.get_boss_name();
  cout << Boss1.get_HP() << endl;
  // Test for boss spell casting and apply cooldown/counting cooldown
  bool BossTurn = true;
  while (BossTurn) {
    cout << "It is the boss turn!" << endl;
    cout << "The boss is attacking..." << endl;
    Boss1.BeginofTurn();
    srand(time(NULL));
    int atktype = rand() % 2;
    if (atktype == 0) {
      cout << "Boss attacks you with his battle axe!" << endl;
      playerDamage = Boss1.UsePhysical();
      BossTurn = false;
      cout << "Player takes " << playerDamage << " physical damage!" << endl;
    } else {
      bool Casted = false;
      while (Casted == false) {
        int i = rand() % 5;
        if (Boss1.UseSpell(i) != "On cooldown") {
          Casted = true;
          cout << "The boss uses " << Boss1.UseSpell(i) << "!" << endl;
          ;
          playerDamage = Boss1.SpellDamage(i);
          cout << "Player takes " << playerDamage << " magical damage!" << endl;
        }
      }
      BossTurn = false;
    }
  }

  vector<Monster> mons; // vectors for storing monster objects
  mons.reserve(10);
  srand(time(NULL));
  for (int i = 0; i < 10; i++) { // create and randomize monsters' stats
    int monHP = rand() % 20;
    int monDamage = rand() % 10;
    mons.push_back(Monster(monHP, monDamage));
  }
  // loop for first 10 rounds
  for (int i = 0; i < 10; i++) {
    if (Player1.getHP() <= 0) {
      cout << "You lost." << endl;
      break;
    }
    cout << "A monster has appeared. Prepare to fight!" << endl;
    cout << "HP: " << mons[i].getMonster_max_HP() << endl;
    cout << "Damage: " << mons[i].getMonsterDamage() << endl;
    int monsterSpeed = rand() % 20 + 1;
    int playerSpeed = rand() % 20 + 1;

    if (monsterSpeed > playerSpeed) {
      turn = 1;
    } else {
      turn = 0;
    }
    while (true) {
      
      if (turn == 1) {
        cout << "Monster's turn: " << endl;
        cout << "The monster attacks you with " << mons[i].getMonsterDamage()
             << " damage!" << endl;
        Player1.takedamage(mons[i].getMonsterDamage());
        cout << "Your HP is " << Player1.getHP() << "." << endl;
        turn = 0;
      } else if (turn == 0) {    
        int choice=0;
        cout << "Your turn:" << endl;
        cout << "What would you like to do?"
             << "\n1. Use sword."
             << "\n2. Use Spell." << endl;
        checkint(choice, 1, 2);
        if (choice == 1) {
          cout << "You attack the monster with your sword. Deal "
               << Player1.physatk() << " physical damage to monster." << endl;
          mons[i].takeDamage(Player1.physatk());
          cout << "Monster HP is " << mons[i].getMonsterHP() << "." << endl;
        } else {
          cout << "Nothing happens." << endl;
        }
        turn = 1;
      }
      if (mons[i].getMonsterHP() <= 0) {
        cout << "Congratulations! You defeated the monster!"
             << "\nRewards (if any) has been added."
             << "\nHP has been recovered by 10." << endl;
        if (mons[i].getMonster_max_HP() == 20) {
          for (int j = 0; j < 5; j++) {
            if (Items[j].find('+') == string::npos) {
              Player1.increase_max_HP(10);
              Items[j] = Items[j] + " +";
              break;
            }
          }
        }
        if (mons[i].getMonsterDamage() == 10) {
          if (Weapons[0].find('+') == string::npos) {
            Player1.increase_phys_damage(10);
            Weapons[0] = "Short Sword +";
          }
        }
        if (mons[i].getMonsterDamage() >= 5 &&
            mons[i].getMonsterDamage() < 10) {
          for (int m = 5; m < 8; m++) {
            if (Items[m].find('+') == string::npos) {
              Player1.increase_spell_damage(5);
              Items[m] = Items[m] + " +";
              break;
            }
          }
        }
        cout << Player1.getMax_HP();
        Player1.roundHPrecover();
        break;
      }
    }
  }

  return 0;
}